from django.contrib import admin

from .models import Puls, SinglePuls

admin.site.register(Puls)
admin.site.register(SinglePuls)
