from django.contrib import admin

from .models import Action

admin.site.register(Action)
